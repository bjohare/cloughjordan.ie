<?php
    echo sprintf(_x('You have received a reply from your listing at %s.', 'contact email', 'WPBDM'), $listing_url);
?>


<?php _ex('Name:', 'contact email', 'WPBDM'); ?> <?php echo $name; ?>

<?php _ex('Email:', 'contact email', 'WPBDM'); ?> <?php echo $email; ?>

<?php _ex('Message:', 'contact email', 'WPBDM'); ?>


<?php echo $message; ?>


<?php _ex('Time:', 'contact email', 'WPBDM'); ?> <?php echo $time; ?>